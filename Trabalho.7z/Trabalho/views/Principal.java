package views;

import Utils.Console;

public class Principal{

    public static void main (String[] args){

            int opcao = 0;
            //Cliente cliente;
            //Produto produto;
            //Funcionario funcionario;

            do{
                System.out.println("\nBem Vindo a Locadora Fire Stars: escolha uma opção.\n");
                System.out.println("1- Cadastrar Cliente: ");
                System.out.println("2- Listar Clientes: ");
                System.out.println("3- Cadastrar Funcionário: ");
                System.out.println("4- Listar Funcionários: ");
                System.out.println("5- Cadastrar Produto: ");
                System.out.println("6- Listar Produto: ");
                System.out.println("7- Cadastrar Locação: ");
                System.out.println("8- Listar Locações: ");
                System.out.println("0- Sair.");
                opcao = Console.readInt("Digite uma opção: ");
                
                switch(opcao){
                    case 1:
                        CadastrarCliente cadastrarCliente = new CadastrarCliente();
                        cadastrarCliente.renderizar();
                        break;
                    case 2:
                        ListarCliente listarCliente = new ListarCliente();
                        listarCliente.renderizar();
                        break;
                    case 3:
                        CadastrarFuncionario cadastrarFuncionario = new CadastrarFuncionario();
                        cadastrarFuncionario.renderizar();
                        break;
                    case 4:
                        ListarFuncionario listarFuncionario = new ListarFuncionario();
                        listarFuncionario.renderizar();
                        break;
                    case 5:
                        CadastrarProduto cadastrarProduto = new CadastrarProduto();
                        cadastrarProduto.renderizar(); 
                        break;
                    case 6:
                        ListarProduto listarProduto = new ListarProduto();
                        listarProduto.renderizar();
                        break;
                    case 7:
                        CadastrarAluguel cadastrarAluguel = new CadastrarAluguel();
                        cadastrarAluguel.renderizar();
                        break;
                    case 8:
                        ListarLocacao listarLocacao = new ListarLocacao();
                        listarLocacao.renderizar();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }while(opcao != 0);

    }
} 