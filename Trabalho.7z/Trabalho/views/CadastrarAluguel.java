package views;

import Controllers.LocarController;
import Models.Locacao;
import Utils.Console;

public class CadastrarAluguel {

    public void renderizar(){
        Locacao aluguel = new Locacao();
        LocarController alugarController = new LocarController();

        System.out.println("\n CADASTRO DE LOCAÇÃO: ");
        aluguel.setCliente(Console.readString("Digite o nome do Cliente: "));
        aluguel.setFuncionario(Console.readString("Digite o nome do funcionário: "));
        aluguel.setProduto(Console.readString("Digite o nome do produto: "));

        alugarController.cadastrar(aluguel);

        System.out.println("\nLocação registrada !!!");
    }
}
