package views;

import Controllers.ProdutoController;
import Models.Produto;
import Utils.Console;

public class CadastrarProduto {

    public void renderizar(){
        Produto Produto= new Produto();
        ProdutoController ProdutoController = new ProdutoController();

        System.out.println("\n -- CADASTRO DE FILMES -- \n");
        Produto.setNome(Console.readString("Digite o nome do Produto: "));
        Produto.setGenero(Console.readString("Informe o Genero: "));
        Produto.setAno(Console.readString("Informe o ano: "));
        Produto.setId(Console.readString("Digite o ID: "));
        Produto.setCla(Console.readInt("Informe a Classificação: "));
        Produto.setDur(Console.readInt("Informe a Duração: "));
        Produto.setTipo(Console.readString("Informe o Tipo: "));
        ProdutoController.cadastrar(Produto);

        System.out.println("\nProduto cadastrado !!!");
    }
    
}
