package views;

import java.util.ArrayList;

import java.lang.Iterable;

import Utils.Console;
import Models.Funcionario;
import Controllers.FuncionarioController;


public class EditarFuncionario {

    int opcao = 0;

    public void editar(){
        ListarFuncionario listarFuncionario = new ListarFuncionario();
        listarFuncionario.renderizar();
        System.out.println("--O QUE DESEJA NO CADASTRO DE FUNCIONÁRIO?--");
        System.out.println("\n1 - Editar funcionário. ");
        System.out.println("\n2 - Remover funcionário. ");
        switch (opcao) {
            case 1:

            break;
            case 2:
                System.out.println("--QUAL FUNCIONÁRIO QUER REMOVER?--");
                int removedElement = listarFuncionario.remove(opcao);
                System.out.println("Removed Element: " + removedElement);
                break;
        }

    }

}
