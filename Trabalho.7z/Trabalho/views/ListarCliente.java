package views;

import Controllers.ClienteController;
import Models.Cliente;
public class ListarCliente {

    public void renderizar(){
        ClienteController clienteController = new ClienteController();        
        System.out.println("\n -- LISTAGEM DE CLIENTES -- \n");
        for (Cliente clienteCadastrado : clienteController.listar()) {
            System.out.println(clienteCadastrado);
        }
    }
    
}
