package views;

public class ProcurarProduto {
    
}
