package views;

import Controllers.LocarController;
import Models.Locacao;

public class ListarLocacao {
    public void renderizar(){
        LocarController locarController = new LocarController();
        System.out.println("\n --LISTA DE ALUGUEIS-- \n");
        for (Locacao locacaoCadastrado : locarController.listar()) {
            System.out.println(locacaoCadastrado);
        }
    }
}
