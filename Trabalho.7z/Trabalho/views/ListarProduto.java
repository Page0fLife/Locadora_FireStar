package views;

import Controllers.ProdutoController;
import Models.Produto;

public class ListarProduto {

    public void renderizar(){
        ProdutoController ProdutoController = new ProdutoController();      
        System.out.println("\n -- LISTAGEM DE FUNCIONÁRIOS -- \n");
        for (Produto ProdutoCadastrado : ProdutoController.listar()) {
            System.out.println(ProdutoCadastrado);
        }
    }
    
}

