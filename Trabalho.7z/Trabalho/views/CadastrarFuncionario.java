package views;

import Controllers.FuncionarioController;
import Models.Funcionario;
import Utils.Console;
import Utils.verificacao;

public class CadastrarFuncionario {

    public void renderizar(){
        Funcionario funcionario= new Funcionario();
        FuncionarioController funcionarioController = new FuncionarioController();

        System.out.println("\n -- CADASTRO DE FUNCIONÁRIOS -- \n");
        funcionario.setNome(Console.readString("Digite o nome do funcionário: "));
        funcionario.setCpf(Console.readString("Digite o CPF do funcionário: "));
        funcionario.setEnd(Console.readString("Digite o endereço do funcionário: "));
        funcionario.setTel(Console.readString("Digite o telefone do funcionário: "));
        funcionario.setTurno(Console.readString("Digite o turno do funcionário: "));
        funcionario.setJorn(Console.readString("Digite a jornada do funcionário: "));
        funcionario.setEmail(Console.readString("Digite o email do funcionário: "));
        funcionario.setCargo(Console.readString("Digite o cargo do funcionário: "));

        if(verificacao.verificarCPF(funcionario.getCpf())){
            if(funcionarioController.cadastrar(funcionario)){
                System.out.println("\n Funcionário cadastrado com sucesso!!");
            }else{
                System.out.println("\n Funcionário já cadastrado!!");
            }
        }else{
            System.out.println("\n Erro no cadastro!!");
            }
    }
    
}
    

