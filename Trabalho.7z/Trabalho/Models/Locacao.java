package Models;

public class Locacao {
     
    private Cliente cliente;
    private Funcionario funcionario;
    private Produto produto;  
    public static void add(Locacao aluguel) {
    }
    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public void setCliente(String readString) {
        return;
    }
    public Funcionario getFuncionario() {
        return funcionario;
    }
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }
    public void setFuncionario(String readString) {
        return;
    }
    public Produto getProduto() {
        return produto;
    }
    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    public void setProduto(String readString) {
        return;
    }

    @Override
    public String toString() {
        return  "Cliente: " + cliente.getNome() + " | Funcionario: " + funcionario.getNome() + " | Produto: " + produto.getNome();
    }

}