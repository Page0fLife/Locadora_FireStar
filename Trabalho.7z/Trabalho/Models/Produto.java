package Models;

public class Produto {

    private String nome;
    private String genero;
    private String ano;
    private String id;
    private int cla;
    private int dur;
    private String tipo;

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAno() {
        return ano;
    }
    public void setAno(String ano) {
        this.ano = ano;
    }

    public String getId(){
        return id;
    }
    public void setId(String id){
        this.id = id;
    }

    public int getCla(){
        return cla;
    }
    public void setCla(int cla){
        this.cla = cla;
    }

    public int getDur(){
        return dur;
    }
    public void setDur(int dur){
        this.dur = dur;
    }

    public String getTipo(){
        return tipo;
    }
    public void setTipo(String tipo){
        this.tipo = tipo;
    }


    @Override
    public String toString() {
        return "Nome: " + nome + " | Genero: " + genero + " | Ano: " + ano + " | Id: " + id + " | Classificação: " + cla + " | Duração: " + dur + " | Tipo: " + tipo;
    }
    
}

