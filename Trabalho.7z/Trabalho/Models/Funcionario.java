package Models;

public class Funcionario {

    private String nome;
    private String cpf;
    private String end;
    private String tel;
    private String turno;
    private int jorn;
    private String sexo;
    private String email;
    private String cargo;


    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }

    public String getCpf(){
        return cpf;
    }
    public void setCpf(String cpf){
        this.cpf = cpf;
    }

    public String getEnd(){
        return end;
    }
    public void setEnd(String end){
        this.end = end;
    }

    public String getTel(){
        return tel;
    }
    public void setTel(String tel){
        this.tel = tel;
    }

    public String getTurno(){
        return turno;
    }
    public void setTurno(String turno){
        this.turno = turno;
    }

    public int getJorn(){
        return jorn;
    }
    public void setJorn(int jorn){
        this.jorn = jorn;
    }

    public String getSexo(){
        return sexo;
    }
    public void setSexo(String sexo){
        this.sexo = sexo;
    }

    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }

    public String getCargo(){
        return cargo;
    }
    public void setCargo(String cargo){
        this.cargo = cargo;
    }

    @Override
    public String toString(){
        return "Nome: " + nome + " | CPF: " + cpf + " | Endereço: " + end + " | Telefone: " + tel + " | Turno: " + turno + " | Jornada: " + jorn + " | Sexo: " + sexo + " | Email: " + email + " | Cargo: " + cargo;
    }
    public void printDetails() {
    }

    

    
}
