package Controllers;

import java.util.ArrayList;

import Models.Locacao;

public class LocarController {

    private static ArrayList<Locacao> alugueis = new ArrayList<Locacao>();

    public void cadastrar(Locacao aluguel) {
        Locacao.add(aluguel);
    }

    public ArrayList<Locacao> listar() {
        return alugueis;
    }

}