package Controllers;

import java.util.ArrayList;

import Models.Produto;

public class ProdutoController {

    private static ArrayList<Produto> produtos = new ArrayList<Produto>();

    public void cadastrar(Produto produto) {
        produtos.add(produto);
     }
    

    public ArrayList<Produto> listar() {
        return produtos;

    }
    public Produto buscarPorCpf(String id){
        for (Produto ProdutoCadastrado : produtos) {
            if(ProdutoCadastrado.getId().equals(id)){
                return ProdutoCadastrado;
            }
        }
        return null;
    }




    
    
}