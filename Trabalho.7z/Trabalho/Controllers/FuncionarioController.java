package Controllers;

import java.util.ArrayList;

import Models.Funcionario;

public class FuncionarioController {
    public boolean cadastrar(Funcionario funcionario) {
        if(buscarPorCpf(funcionario.getCpf()) == null){
            funcionarios.add(funcionario);
            System.out.println("Cliente cadastrado com sucesso!!");
            return true; 
        }
        return false;
    }


    private static ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();

    public ArrayList<Funcionario> listar(){
        return funcionarios;
    }

    public Funcionario buscarPorCpf(String cpf){
        for (Funcionario FuncionarioCadastrado : funcionarios) {
            if(FuncionarioCadastrado.getCpf().equals(cpf)){
                return FuncionarioCadastrado;
            }
        }
        return null;
    }
}
