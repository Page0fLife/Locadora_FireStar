package Controllers;

import java.util.ArrayList;

import Models.Cliente;

public class ClienteController {
    public boolean cadastrar(Cliente cliente) {
        if(buscarPorCpf(cliente.getCpf()) == null){
            clientes.add(cliente);
            System.out.println("Cliente cadastrado com sucesso!!");
            return true; 
        }
        return false;
    }

    private static ArrayList<Cliente> clientes = new ArrayList<Cliente>();


    public ArrayList<Cliente> listar() {
        return clientes;

    }
    
    public Cliente buscarPorCpf(String cpf){
        for (Cliente clienteCadastrado : clientes) {
            if(clienteCadastrado.getCpf().equals(cpf)){
                return clienteCadastrado;
            }
        }
        return null;
    }
    
}