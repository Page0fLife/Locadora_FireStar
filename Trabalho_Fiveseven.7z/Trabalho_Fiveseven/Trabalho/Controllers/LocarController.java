package Controllers;

import java.util.ArrayList;

import Models.Locacao;

public class LocarController{

    private static ArrayList<Locacao> alugueis = new ArrayList<Locacao>();
    public void cadastrar(Locacao aluguel) {
        alugueis.add(aluguel);
    }
    public ArrayList<Locacao> listar() {
        return alugueis;
    }
    public void multar(int diasAtrasados){
        double multa = 5.00;

        if (diasAtrasados > 3) {
            System.out.println("A multa a ser paga é de " + multa*diasAtrasados);
        }
        else{
            System.out.println("A multa a ser paga é de " + multa);
        }

    }

}