package Controllers;

import java.util.ArrayList;

import Controllers.contracts.IFuncionariocontroller;
import Models.Funcionario;

public class FuncionarioController implements IFuncionariocontroller{
    @Override
    public boolean cadastrar(Funcionario funcionario) {
        if(buscarPorCpf(funcionario.getCpf()) == null){
            funcionarios.add(funcionario);
            System.out.println("Cliente cadastrado com sucesso!!");
            return true; 
        }
        return false;
    }

    
    private static ArrayList<Funcionario> funcionarios = new ArrayList<Funcionario>();
    @Override
    public ArrayList<Funcionario> listar(){
        return funcionarios;
    }
    @Override
    public Funcionario buscarPorCpf(String cpf){
        for (Funcionario FuncionarioCadastrado : funcionarios) {
            if(FuncionarioCadastrado.getCpf().equals(cpf)){
                System.out.println("\nFuncionário encontrado!!! " + FuncionarioCadastrado);
                return FuncionarioCadastrado;
            }
    }
    return null;
}
    @Override
    public Funcionario removerPorCpf(String cpf){
    funcionarios.remove(buscarPorCpf(cpf));
    return null;
}
}
