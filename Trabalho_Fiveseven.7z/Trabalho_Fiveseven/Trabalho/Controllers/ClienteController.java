package Controllers;

import java.util.ArrayList;

import Controllers.contracts.IClientesController;
import Models.Cliente;

public class ClienteController implements IClientesController {

    @Override
    public boolean cadastrar(Cliente cliente) {
        if(buscarPorCpf(cliente.getCpf()) == null){
            clientes.add(cliente);
            System.out.println("Cliente cadastrado com sucesso!!");
            return true; 
        }
        return false;
    }
    
   
     static ArrayList<Cliente> clientes = new ArrayList<Cliente>();

    @Override
    public ArrayList<Cliente> listar() {
        return clientes;

    }
    @Override
    public Cliente buscarPorCpf(String cpf){
        for (Cliente clienteCadastrado : clientes) {
            if(clienteCadastrado.getCpf().equals(cpf)){
                System.out.println("\nCliente encontrado!!! " + clienteCadastrado);
                return clienteCadastrado;
            }
        }
        return null;
    }
    @Override
    public Cliente removerPorCpf(String cpf){
        clientes.remove(buscarPorCpf(cpf));
        return null;
    }
}