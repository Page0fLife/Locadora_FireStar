package Controllers;

import java.util.ArrayList;

import Controllers.contracts.IProdutoController;
import Models.Produto;

public class ProdutoController implements IProdutoController {

    private static ArrayList<Produto> produtos = new ArrayList<Produto>();
    @Override
    public void cadastrar(Produto produto) {
        produtos.add(produto);
     }
    
     @Override 
    public ArrayList<Produto> listar() {
        return produtos;

    }
    @Override
    public Produto buscarPorCpf(String id){
        for (Produto ProdutoCadastrado : produtos) {
            if(ProdutoCadastrado.getId().equals(id)){
                return ProdutoCadastrado;
            }
        }
        return null;
    }




    
    
}