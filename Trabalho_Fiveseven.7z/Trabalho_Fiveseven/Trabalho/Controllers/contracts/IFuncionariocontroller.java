package Controllers.contracts;

import java.util.ArrayList;

import Models.Funcionario;

public interface IFuncionariocontroller {
    
    boolean cadastrar(Funcionario funcionario);
    ArrayList<Funcionario> listar();
    Funcionario buscarPorCpf(String cpf);
    Funcionario removerPorCpf(String cpf);

    


    

}
