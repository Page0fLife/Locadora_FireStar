package Controllers.contracts;

import java.util.ArrayList;

import Models.Cliente;

public interface IClientesController {
    
     boolean cadastrar(Cliente cliente);
     ArrayList<Cliente> listar();
     Cliente buscarPorCpf(String cpf);
     Cliente removerPorCpf(String cpf);
    

}
