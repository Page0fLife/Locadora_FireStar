package Controllers.contracts;

import java.util.ArrayList;

import Models.Produto;

public interface IProdutoController {
    
    void cadastrar(Produto produto);
    ArrayList<Produto> listar();
    Produto buscarPorCpf(String id);

}
