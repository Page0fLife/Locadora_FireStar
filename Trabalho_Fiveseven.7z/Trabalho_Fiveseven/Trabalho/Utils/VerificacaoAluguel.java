package Utils;

import java.util.Calendar; 
import java.util.Date; 
import java.text.DateFormat; 
import java.text.SimpleDateFormat; 

public class VerificacaoAluguel {
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss"); 
    
    public void verificar(){
        Date currentDate = new Date(); 
        System.out.println(dateFormat.format(currentDate));

        Calendar c = Calendar.getInstance(); 
        c.setTime(currentDate); 
        c.add(Calendar.DATE, 7); 
        Date currentDatePlusOne = c.getTime(); 
        
        System.out.println(dateFormat.format(currentDatePlusOne)); 
        if (currentDate.equals(currentDatePlusOne)) { 
            System.out.println("--Dia final da locação--"); 
        } 
    }
} 
 
