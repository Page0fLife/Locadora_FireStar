package Models;

import java.util.Date;

public class Locacao {
     
    private String cliente;
    private String produto;
    private Date entrega;   
    
    public Date getEntrega() {
        return entrega;
    }
    public void setEntrega(Date entrega) {
        this.entrega = entrega;
    }
    public String getCliente() {
        return cliente;
    }
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    public String getProduto() {
        return produto;
    }
    public void setProduto(String produto) {
        this.produto = produto;
    }
    @Override
    public String toString() {
        return  "Cliente " + cliente + " alugou " + produto + " para devolver em " + entrega;
    }

}