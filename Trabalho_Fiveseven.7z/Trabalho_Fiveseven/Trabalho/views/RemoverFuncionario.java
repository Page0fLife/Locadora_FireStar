package views;

import Utils.Console;
import views.contracts.IRemoverFuncionario;
import Controllers.FuncionarioController;

public class RemoverFuncionario implements IRemoverFuncionario {

    int opcao = 0;
    @Override
    public void remover(){
        ListarFuncionario listarFuncionario = new ListarFuncionario();
        listarFuncionario.renderizar();
        FuncionarioController funcionarioController = new FuncionarioController();

        System.out.println("--DESEJA MESMO REMOVER FUNCIONÁRIO?--");
        System.out.println("\n1 - Sim ");
        System.out.println("\n2 - Não ");
        opcao = Console.readInt("Digite uma opção deseja: ");
        switch (opcao) {
            case 1:
                System.out.println("--QUAL FUNCIONÁRIO QUER REMOVER?--");
                funcionarioController.removerPorCpf(Console.readString("Digite um cpf: "));
                break;
            case 2:
                break;
        }
    }
}
