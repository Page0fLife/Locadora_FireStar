package views;

import Controllers.FuncionarioController;
import Utils.Console;
import views.contracts.IProcurarFuncionario;

public class ProcurarFuncionario implements IProcurarFuncionario {
    @Override
    public void renderizar(){
        FuncionarioController funcionarioController = new FuncionarioController();

        funcionarioController.buscarPorCpf(Console.readString("Digite um cpf: "));
   }
    
}
