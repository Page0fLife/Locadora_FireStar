package views;

import Controllers.ProdutoController;
import Models.Produto;
import views.contracts.IListarProduto;

public class ListarProduto implements IListarProduto{
    @Override
    public void renderizar(){
        ProdutoController ProdutoController = new ProdutoController();      
        System.out.println("\n -- LISTAGEM DE FUNCIONÁRIOS -- \n");
        for (Produto ProdutoCadastrado : ProdutoController.listar()) {
            System.out.println(ProdutoCadastrado);
        }
    }
    
}

