package views.contracts;

public interface IListarFuncionarios {

    void renderizar();
    
}
