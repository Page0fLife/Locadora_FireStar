package views.contracts;

public interface ICadastrarAluguel {
    
    void renderizar();

}
