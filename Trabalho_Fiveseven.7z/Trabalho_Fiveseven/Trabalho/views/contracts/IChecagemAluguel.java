package views.contracts;

public interface IChecagemAluguel {
    
    void renderizar();
}
