package views.contracts;

public interface IProcurarFuncionario {
    
    void renderizar();
    
}
