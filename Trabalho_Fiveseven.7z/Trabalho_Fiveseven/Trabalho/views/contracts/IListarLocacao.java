package views.contracts;

public interface IListarLocacao {
    void renderizar();
}
