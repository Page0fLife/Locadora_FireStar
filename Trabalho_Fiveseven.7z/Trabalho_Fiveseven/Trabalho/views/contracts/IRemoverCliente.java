package views.contracts;

public interface IRemoverCliente {
    
    void remover();

}
