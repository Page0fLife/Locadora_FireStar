package views.contracts;

public interface IRemoverFuncionario {
    void remover();
}
