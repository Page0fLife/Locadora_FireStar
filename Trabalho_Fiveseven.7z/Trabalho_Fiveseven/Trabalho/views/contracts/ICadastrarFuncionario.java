package views.contracts;

public interface ICadastrarFuncionario {

    void renderizar();
    
}
