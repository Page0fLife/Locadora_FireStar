package views.contracts;

public interface IListarCliente  {
    
    void renderizar();

}
