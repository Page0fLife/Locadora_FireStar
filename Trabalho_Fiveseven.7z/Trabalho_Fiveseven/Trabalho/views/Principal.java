package views;

import Utils.Console;

public class Principal{
    public static void main(String[] args) {

            int opcao = 0;
            //Cliente cliente;
            //Produto produto;
            //Funcionario funcionario;

            do{
                System.out.println("\nBem Vindo a Locadora Fire Stars: escolha uma opção.\n");
                System.out.println("1- Cadastrar Cliente: ");
                System.out.println("2- Listar Clientes: ");
                System.out.println("3- Procurar Clientes: ");
                System.out.println("4- Remover Clientes: ");
                System.out.println("5- Cadastrar Funcionário: ");
                System.out.println("6- Listar Funcionários: ");
                System.out.println("7- Procurar Funcionários: ");
                System.out.println("8- Remover Funcionários: ");
                System.out.println("9- Cadastrar Produto: ");
                System.out.println("10- Listar Produto: ");
                System.out.println("11- Cadastrar Locação: ");
                System.out.println("12- Listar Locações: ");
                System.out.println("13- Checar multa de atraso de aluguel: ");
                System.out.println("0- Sair.");
                opcao = Console.readInt("Digite uma opção: ");
                
                switch(opcao){
                    case 1:
                        CadastrarCliente cadastrarCliente = new CadastrarCliente();
                        cadastrarCliente.renderizar();
                        break;
                    case 2:
                        ListarCliente listarCliente = new ListarCliente();
                        listarCliente.renderizar();
                        break;
                    case 3:
                        ProcurarCliente procurarCliente = new ProcurarCliente();
                        procurarCliente.renderizar();
                        break;
                    case 4:
                        RemoverCliente removerCliente = new RemoverCliente();
                        removerCliente.remover();
                        break;
                    case 5:
                        CadastrarFuncionario cadastrarFuncionario = new CadastrarFuncionario();
                        cadastrarFuncionario.renderizar();
                    case 6:
                        ListarFuncionario listarFuncionario = new ListarFuncionario();
                        listarFuncionario.renderizar();
                        break;
                    case 7:
                        ProcurarFuncionario procurarFuncionario = new ProcurarFuncionario();
                        procurarFuncionario.renderizar();
                        break;
                    case 8:
                        RemoverFuncionario removerFuncionario = new RemoverFuncionario();
                        removerFuncionario.remover();
                        break;
                    case 9:
                        CadastrarProduto cadastrarProduto = new CadastrarProduto();
                        cadastrarProduto.renderizar(); 
                        break;
                    case 10:
                        ListarProduto listarProduto = new ListarProduto();
                        listarProduto.renderizar();
                        break;
                    case 11:
                        CadastrarAluguel cadastrarAluguel = new CadastrarAluguel();
                        cadastrarAluguel.renderizar();
                        break;
                    case 12:
                        ListarLocacao listarLocacao = new ListarLocacao();
                        listarLocacao.renderizar();
                        break;
                    case 13:
                        ChecagemAluguel checagemAluguel = new ChecagemAluguel();
                        checagemAluguel.renderizar();
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }while(opcao != 0);
    }
} 