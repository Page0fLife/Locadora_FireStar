package views;

import Utils.Console;
import views.contracts.IRemoverCliente;
import Controllers.ClienteController;

public class RemoverCliente implements IRemoverCliente{

    int opcao = 0;
    @Override
    public void remover(){
        ListarCliente listarCliente = new ListarCliente();
        listarCliente.renderizar();
        ClienteController clienteController = new ClienteController();

        System.out.println("--DESEJA MESMO REMOVER CLIENTE?--");
        System.out.println("\n1 - Sim ");
        System.out.println("\n2 - Não ");
        opcao = Console.readInt("Digite uma opção deseja: ");
        switch (opcao) {
            case 1:
                System.out.println("--QUAL CLIENTE QUER REMOVER?--");
                clienteController.removerPorCpf(Console.readString("Digite um cpf: "));
                break;
            case 2:
                break;
        }

    }
}
